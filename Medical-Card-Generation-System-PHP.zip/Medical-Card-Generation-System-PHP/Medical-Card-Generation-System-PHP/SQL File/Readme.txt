How to run the Medical Card Generation System Project using PHP and MySQL

1. Download the project zip file

2. Extract the file and copy mcgs folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/Html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name  mgsdb

6. Import mgsdb.sql file(given inside the zip package in SQL file folder)

7. Run the script http://localhost/mcgs

*************************Admin Login Details**********************************

Username: admin

Password: Test@123