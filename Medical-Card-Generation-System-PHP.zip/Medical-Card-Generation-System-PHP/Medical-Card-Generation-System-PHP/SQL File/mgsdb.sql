

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mgsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Admin', 'admin', 1234567891, 'adminuser@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2024-07-10 06:44:27');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontact`
--

CREATE TABLE `tblcontact` (
  `ID` int(10) NOT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Message` mediumtext DEFAULT NULL,
  `EnquiryDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `IsRead` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcontact`
--

INSERT INTO `tblcontact` (`ID`, `Name`, `Email`, `Message`, `EnquiryDate`, `IsRead`) VALUES
(1, 'Akash', 'akash01@gmail.com', 'Aakash Wagh please Create my Medical Card', '2024-08-11 07:26:24', 1),
(2, 'Anuj', 'anuj@gamil.COM', 'This is for testing.', '2024-08-17 08:55:16', 1),
(3, 'Rajat kale', 'raj@gmail.com', 'Test test', '2024-08-21 05:07:23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblmedicalcard`
--

CREATE TABLE `tblmedicalcard` (
  `ID` int(5) NOT NULL,
  `RefNumber` int(10) DEFAULT NULL,
  `FullName` varchar(250) DEFAULT NULL,
  `ProfileImage` varchar(250) DEFAULT NULL,
  `ContactNumber` bigint(11) DEFAULT NULL,
  `Email` varchar(250) DEFAULT NULL,
  `BloodGroup` varchar(100) DEFAULT NULL,
  `Age` int(5) DEFAULT NULL,
  `Gender` varchar(50) DEFAULT NULL,
  `Address` mediumtext DEFAULT NULL,
  `MedicalCond` mediumtext DEFAULT NULL,
  `IssuedDate` varchar(200) DEFAULT NULL,
  `ValidDate` varchar(200) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblmedicalcard`
--

INSERT INTO `tblmedicalcard` (`ID`, `RefNumber`, `FullName`, `ProfileImage`, `ContactNumber`, `Email`, `BloodGroup`, `Age`, `Gender`, `Address`, `MedicalCond`, `IssuedDate`, `ValidDate`, `CreationDate`) VALUES
(1, 687246123, 'Tejya Gunjal', 'Tejya_pic.jpg', 7038198092, 'tejyag90@gmail.com', 'A+', 24, 'Male', 'Bhum, Dharashiv, India, 413650', 'H-Broken', '2024-07-08', '2025-11-01', '2024-07-09 05:35:29'),
(2, 478706795, 'Manasi Jadhav', 'manasi_pic.jpg', 9284302873, 'manasij73@gmail.com', 'O+', 21, 'Female', 'Satara, Maharashtra, India,415002', 'Asthama', '2024-07-28', '2025-011-30', '2024-07-29 05:38:45'),
(3, 152951869, 'Komal Panchal', 'Komal_pic.jpg', 7620977114, 'komal@gmail.com', 'B+', 23, 'Female', 'Hadapsar, Pune, Maharashtra, India, 411028', 'No', '2024-08-04', '2025-12-01', '2024-08-05 05:35:59');


-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--

CREATE TABLE `tblpage` (
  `ID` int(10) NOT NULL,
  `PageType` varchar(200) DEFAULT NULL,
  `PageTitle` varchar(200) DEFAULT NULL,
  `PageDescription` mediumtext DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `UpdationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpage`
--

INSERT INTO `tblpage` (`ID`, `PageType`, `PageTitle`, `PageDescription`, `Email`, `MobileNumber`, `UpdationDate`) VALUES
(1, 'aboutus', 'About us', '<font color=\"#747474\" face=\"Roboto, sans-serif, arial\"><span style=\"font-size: 13px;\"><b>Welcome to Medical Card Generetion System..!

We’re dedicated to making healthcare simpler by providing an easy way to generate personalized medical cards. Our user-friendly platform ensures you have your vital health information at your fingertips, whenever you need it.

With a focus on security and privacy, our team is passionate about enhancing accessibility to health resources. Trust us to help you manage your health with ease!

Thank you for choosing...!.</b></span></font><br>', NULL, NULL, '2024-09-26 01:07:10'),
(2, 'contactus', 'Contact Us', '#81 Shubh Complex, Vadodara, Gujarat, India, 380012', 'medicard@gmail.com', 639700329, '2024-09-26 01:08:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcontact`
--
ALTER TABLE `tblcontact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblmedicalcard`
--
ALTER TABLE `tblmedicalcard`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpage`
--
ALTER TABLE `tblpage`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcontact`
--
ALTER TABLE `tblcontact`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblmedicalcard`
--
ALTER TABLE `tblmedicalcard`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblpage`
--
ALTER TABLE `tblpage`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
