  <footer class="footer-area section-padding">
        
        <div class="footer-copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-12">
                        <span>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> Medical Card Generation System </span>
                    </div>
                 
                </div>
            </div>
        </div>
    </footer>